#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QMessageBox>
#include <QString>
#include <QResizeEvent>
#include <QtSerialPort>
#include <QLabel>
#include <QList>
#include <QElapsedTimer>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

    QPixmap robot_bkgnd;
    QPixmap main_bkgnd;
    QPixmap compas_bkgnd;
    QLabel* label_10 = new QLabel( this );

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void resizeEvent(QResizeEvent *event);

    void readData();

    void on_startButton_clicked();

    void on_stopButton_clicked();

    void on_updateButton_clicked();

    void on_batteryProgressBar_valueChanged(int value);

    void on_connectButton_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort * COMPORT;
    QString data_from_serialPort;
    bool is_data_received = false;


    void cutString(const QString& input);
    QByteArray makeDataFrame(char instruction);

    void displayBattery();
    void displaySensors();
    void displayEncoders();
    void displayData();

    void displayStats();
    //cleandata from serialPort

    QList<QFrame*> frameList;

    int status;
    int sensors[20];
    int pwm_L;
    int pwm_R;
    float w_L;
    float w_R;
    int z_rotation;
    int battery;


    //data to send
    char instruction;
    int data_to_send[4];



    //calculated data

    float linear_velocity;
    float max_linear_velocity;
    float average_velocity;
    float distanceFloat;
    float time;


};

#endif // MAINWINDOW_H
